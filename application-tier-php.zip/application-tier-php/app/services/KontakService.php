<?php
// File: app/services/KontakService.php
class KontakService {
    private $kontak; // DAO/Repository

    public function __construct(Kontak $kontak) {
        $this->kontak = $kontak;
    }

    public function getAll() {
        $stmt = $this->kontak->getAll();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById(int $id) {
        $this->kontak->id = $id;
        return $this->kontak->getById();
    }

    public function create(array $input) {
        $this->validateRequired($input, ['nama', 'telepon']);
        $input = $this->sanitize($input);
        $this->kontak->nama = $input['nama'];
        $this->kontak->telepon = $input['telepon'];
        $this->kontak->email = $input['email'] ?? null;
        if ($this->kontak->create()) {
            return [
                'id' => $this->kontak->id,
                'nama' => $this->kontak->nama,
                'telepon' => $this->kontak->telepon,
                'email' => $this->kontak->email
            ];
        }
        throw new Exception('Gagal menambahkan kontak');
    }

    public function update(int $id, array $input) {
        $this->validateRequired($input, ['nama', 'telepon']);
        $input = $this->sanitize($input);
        $this->kontak->id = $id;
        $this->kontak->nama = $input['nama'];
        $this->kontak->telepon = $input['telepon'];
        $this->kontak->email = $input['email'] ?? null;
        if (!$this->kontak->update()) {
            throw new Exception('Gagal memperbarui data atau data tidak ditemukan');
        }
    }

    public function delete(int $id) {
        $this->kontak->id = $id;
        if (!$this->kontak->delete()) {
            throw new Exception('Gagal menghapus data atau data tidak ditemukan');
        }
    }

    private function validateRequired(array $input, array $requiredFields): void {
        $missing = [];
        foreach ($requiredFields as $field) {
            if (!isset($input[$field]) || empty(trim($input[$field]))) {
                $missing[] = $field;
            }
        }
        if (!empty($missing)) {
            throw new Exception('Field wajib: ' . implode(', ', $missing));
        }
    }

    private function sanitize($data) {
        if (is_array($data)) {
            return array_map([$this, 'sanitize'], $data);
        }
        return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
    }
}
?>