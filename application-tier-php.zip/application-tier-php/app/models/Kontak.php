<?php
// File: app/models/Kontak.php
class Kontak extends Model {
    
    public $id;
    public $nama;
    public $telepon;
    public $email;

    public function __construct($db) {
        parent::__construct($db);
        $this->table = "kontaks";
    }

    public function getAll() {
        $query = "SELECT * FROM {$this->table} ORDER BY created_at DESC";
        return $this->executeQuery($query);
    }

    public function getById() {
        $query = "SELECT * FROM {$this->table} WHERE id = :id LIMIT 1";
        $stmt = $this->executeQuery($query, [':id' => $this->id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $this->nama = $row['nama'];
            $this->telepon = $row['telepon'];
            $this->email = $row['email'];
            return $row;
        }

        return false;
    }

    public function create() {
        $query = "INSERT INTO {$this->table} 
                  (nama, telepon, email) 
                  VALUES (:nama, :telepon, :email)";

        $params = [
            ':nama' => $this->nama,
            ':telepon' => $this->telepon,
            ':email' => $this->email
        ];

        $stmt = $this->executeQuery($query, $params);

        if ($stmt) {
            $this->id = $this->conn->lastInsertId();
            return true;
        }

        return false;
    }

    public function update() {
        $query = "UPDATE {$this->table} 
                  SET nama = :nama, 
                      telepon = :telepon, 
                      email = :email,
                      updated_at = CURRENT_TIMESTAMP
                  WHERE id = :id";

        $params = [
            ':id' => $this->id,
            ':nama' => $this->nama,
            ':telepon' => $this->telepon,
            ':email' => $this->email
        ];

        $stmt = $this->executeQuery($query, $params);
        return $stmt->rowCount() > 0;
    }

    public function delete() {
        $query = "DELETE FROM {$this->table} WHERE id = :id";
        $stmt = $this->executeQuery($query, [':id' => $this->id]);
        return $stmt->rowCount() > 0;
    }
}
?>