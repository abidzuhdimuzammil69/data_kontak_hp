<?php
// File: app/config/Config.php
class Config {
    public static $DB_HOST = "localhost";
    public static $DB_NAME = "kontakproyek";
    public static $DB_USER = "root";
    public static $DB_PASS = "";
    public static $DB_CHARSET = "utf8mb4";
    
    public static $APP_NAME = "Kontak Manager API";
    public static $DEBUG_MODE = true;
}
?>