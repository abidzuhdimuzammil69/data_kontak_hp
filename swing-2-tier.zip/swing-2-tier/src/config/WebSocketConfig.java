package config;

import javax.swing.JOptionPane;

public class WebSocketConfig {
    private static WebSocketConfig instance;
    
    private WebSocketConfig() {
        // Constructor private untuk singleton
    }
    
    public static WebSocketConfig getInstance() {
        if (instance == null) {
            instance = new WebSocketConfig();
        }
        return instance;
    }
    
    public void addMessageHandler(MessageHandler handler) {
        // Simulasi handler
    }
    
    public void sendMessage(String message) {
        // Simulasi pengiriman notifikasi (akan ditampilkan di UI)
        System.out.println("WebSocket Notification: " + message);
    }
    
    public interface MessageHandler {
        void handleMessage(String message);
    }
}