package worker.kontak;

import model.Kontak;
import service.KontakService;
import view.KontakFrame;
import javax.swing.*;

public class UpdateKontakWorker extends SwingWorker<Void, Void> {
    private final KontakFrame frame;
    private final KontakService kontakService;
    private final Kontak kontak;

    public UpdateKontakWorker(KontakFrame frame, KontakService kontakService, Kontak kontak) {
        this.frame = frame;
        this.kontakService = kontakService;
        this.kontak = kontak;
        frame.getProgressBar().setIndeterminate(true);
        frame.getProgressBar().setString("Memperbarui kontak...");
    }

    @Override
    protected Void doInBackground() throws Exception {
        kontakService.updateKontak(kontak);
        return null;
    }

    @Override
    protected void done() {
        frame.getProgressBar().setIndeterminate(false);
        try {
            get();
            frame.getProgressBar().setString("Kontak berhasil diperbarui");
            JOptionPane.showMessageDialog(frame, 
                "Kontak berhasil diperbarui!", 
                "Sukses", 
                JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            frame.getProgressBar().setString("Gagal memperbarui");
            JOptionPane.showMessageDialog(frame,
                    "Error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}