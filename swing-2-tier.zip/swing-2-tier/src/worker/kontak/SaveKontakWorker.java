package worker.kontak;

import model.Kontak;
import service.KontakService;
import view.KontakFrame;
import javax.swing.*;

public class SaveKontakWorker extends SwingWorker<Void, Void> {
    private final KontakFrame frame;
    private final KontakService kontakService;
    private final Kontak kontak;

    public SaveKontakWorker(KontakFrame frame, KontakService kontakService, Kontak kontak) {
        this.frame = frame;
        this.kontakService = kontakService;
        this.kontak = kontak;
        frame.getProgressBar().setIndeterminate(true);
        frame.getProgressBar().setString("Menyimpan kontak...");
    }

    @Override
    protected Void doInBackground() throws Exception {
        kontakService.createKontak(kontak);
        return null;
    }

    @Override
    protected void done() {
        frame.getProgressBar().setIndeterminate(false);
        try {
            get();
            frame.getProgressBar().setString("Kontak berhasil disimpan");
            JOptionPane.showMessageDialog(frame, 
                "Kontak berhasil disimpan!", 
                "Sukses", 
                JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            frame.getProgressBar().setString("Gagal menyimpan");
            JOptionPane.showMessageDialog(frame,
                    "Error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}