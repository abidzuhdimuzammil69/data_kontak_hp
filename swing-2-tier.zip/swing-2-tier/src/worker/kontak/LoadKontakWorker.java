package worker.kontak;

import model.Kontak;
import service.KontakService;
import view.KontakFrame;
import javax.swing.*;
import java.util.List;

public class LoadKontakWorker extends SwingWorker<List<Kontak>, Void> {
    private final KontakFrame frame;
    private final KontakService kontakService;

    public LoadKontakWorker(KontakFrame frame, KontakService kontakService) {
        this.frame = frame;
        this.kontakService = kontakService;
        frame.getProgressBar().setIndeterminate(true);
        frame.getProgressBar().setString("Memuat data kontak...");
    }

    @Override
    protected List<Kontak> doInBackground() throws Exception {
        return kontakService.getAllKontak();
    }

    @Override
    protected void done() {
        frame.getProgressBar().setIndeterminate(false);
        try {
            List<Kontak> result = get();
            frame.getProgressBar().setString(result.size() + " kontak dimuat");
        } catch (Exception e) {
            frame.getProgressBar().setString("Gagal memuat data");
            JOptionPane.showMessageDialog(frame,
                    "Error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}