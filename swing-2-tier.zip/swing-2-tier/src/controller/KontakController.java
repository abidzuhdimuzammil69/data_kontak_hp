package controller;

import config.WebSocketConfig;
import model.Kontak;
import service.KontakService;
import service.KontakServiceDefault;
import view.KontakDialog;
import view.KontakFrame;
import worker.kontak.*;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class KontakController {
    private final KontakFrame frame;
    private final KontakService kontakService = new KontakServiceDefault();
    private List<Kontak> allKontak = new ArrayList<>();
    private List<Kontak> displayedKontak = new ArrayList<>();

    public KontakController(KontakFrame frame) {
        this.frame = frame;
        setupEventListeners();
        loadAllKontak();
    }

    private void setupEventListeners() {
        // Add button
        frame.getAddButton().addActionListener(e -> openKontakDialog(null));
        
        // Refresh button
        frame.getRefreshButton().addActionListener(e -> loadAllKontak());
        
        // Delete button
        frame.getDeleteButton().addActionListener(e -> deleteSelectedKontak());
        
        // Export button
        frame.getExportButton().addActionListener(e -> exportToPDF());
        
        // Double-click to edit
        frame.getKontakTable().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int selectedRow = frame.getKontakTable().getSelectedRow();
                    if (selectedRow >= 0) {
                        openKontakDialog(displayedKontak.get(selectedRow));
                    }
                }
            }
        });
        
        // Search filter
        frame.getSearchField().getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { applySearchFilter(); }
            @Override
            public void removeUpdate(DocumentEvent e) { applySearchFilter(); }
            @Override
            public void changedUpdate(DocumentEvent e) { applySearchFilter(); }
            
            private void applySearchFilter() {
                String keyword = frame.getSearchField().getText().trim();
                if (keyword.isEmpty()) {
                    displayedKontak = new ArrayList<>(allKontak);
                } else {
                    displayedKontak = kontakService.searchKontak(keyword);
                }
                frame.getKontakTableModel().setKontakList(displayedKontak);
                updateTotalRecordsLabel();
            }
        });
    }

    private void openKontakDialog(Kontak kontakToEdit) {
        KontakDialog dialog;
        
        if (kontakToEdit == null) {
            dialog = new KontakDialog(frame);
        } else {
            dialog = new KontakDialog(frame, kontakToEdit);
        }
        
        dialog.getSaveButton().addActionListener(e -> {
            Kontak kontak = dialog.getKontak();
            
            // Validasi input
            if (kontak.getNama().isEmpty() || kontak.getTelepon().isEmpty()) {
                JOptionPane.showMessageDialog(dialog, 
                    "Nama dan Telepon harus diisi!", 
                    "Validasi Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            SwingWorker<Void, Void> worker;
            
            if (kontakToEdit == null) {
                worker = new SaveKontakWorker(frame, kontakService, kontak);
            } else {
                worker = new UpdateKontakWorker(frame, kontakService, kontak);
            }
            
            worker.addPropertyChangeListener(evt -> {
                if (SwingWorker.StateValue.DONE.equals(evt.getNewValue())) {
                    try {
                        worker.get();
                        dialog.dispose();
                        loadAllKontak();
                    } catch (Exception ex) {
                        // Error sudah ditangani di worker
                    }
                }
            });
            worker.execute();
        });
        
        dialog.setVisible(true);
    }

    private void deleteSelectedKontak() {
        int selectedRow = frame.getKontakTable().getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(frame, "Pilih kontak yang akan dihapus.");
            return;
        }
        
        Kontak kontak = displayedKontak.get(selectedRow);
        int confirm = JOptionPane.showConfirmDialog(frame,
                "Hapus kontak: " + kontak.getNama() + " - " + kontak.getTelepon() + "?",
                "Konfirmasi Hapus", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            DeleteKontakWorker worker = new DeleteKontakWorker(frame, kontakService, kontak);
            worker.addPropertyChangeListener(evt -> {
                if (SwingWorker.StateValue.DONE.equals(evt.getNewValue())) {
                    loadAllKontak();
                }
            });
            worker.execute();
        }
    }

    private void loadAllKontak() {
        frame.getProgressBar().setIndeterminate(true);
        frame.getProgressBar().setString("Memuat data...");
        
        LoadKontakWorker worker = new LoadKontakWorker(frame, kontakService);
        worker.addPropertyChangeListener(evt -> {
            if (SwingWorker.StateValue.DONE.equals(evt.getNewValue())) {
                try {
                    allKontak = worker.get();
                    displayedKontak = new ArrayList<>(allKontak);
                    frame.getKontakTableModel().setKontakList(displayedKontak);
                    updateTotalRecordsLabel();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Gagal memuat data: " + ex.getMessage());
                } finally {
                    frame.getProgressBar().setIndeterminate(false);
                }
            }
        });
        worker.execute();
    }

    private void exportToPDF() {
        try {
            // Simple message for PDF export
            JOptionPane.showMessageDialog(frame, 
                "Fitur export PDF akan diimplementasikan dengan library iText/Apache PDFBox\n" +
                "Untuk implementasi lengkap, tambahkan dependency PDF library", 
                "Info Export", 
                JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, 
                "Error export: " + e.getMessage(), 
                "Export Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateTotalRecordsLabel() {
        frame.getTotalRecordsLabel().setText(displayedKontak.size() + " Kontak");
    }
}