package service;

import java.util.List;
import model.Kontak;

public interface KontakService {
    void createKontak(Kontak kontak);
    void updateKontak(Kontak kontak);
    void deleteKontak(Kontak kontak);
    List<Kontak> getAllKontak();
    List<Kontak> searchKontak(String keyword);
}