package service;

import dao.KontakDao;
import dao.mysql.KontakDaoMySql;
import model.Kontak;
import java.util.List;
import javax.swing.JOptionPane;

public class KontakServiceDefault implements KontakService {
    private final KontakDao kontakDao = new KontakDaoMySql();

    @Override
    public void createKontak(Kontak kontak) {
        kontakDao.insert(kontak);
        showNotification("Kontak baru ditambahkan: " + kontak.getNama());
    }

    @Override
    public void updateKontak(Kontak kontak) {
        kontakDao.update(kontak);
        showNotification("Kontak diperbarui: " + kontak.getNama());
    }

    @Override
    public void deleteKontak(Kontak kontak) {
        kontakDao.delete(kontak.getId());
        showNotification("Kontak dihapus: " + kontak.getNama());
    }

    @Override
    public List<Kontak> getAllKontak() {
        return kontakDao.findAll();
    }

    @Override
    public List<Kontak> searchKontak(String keyword) {
        return kontakDao.searchByNama(keyword);
    }
    
    private void showNotification(String message) {
        // Simulasi notifikasi (bisa diganti dengan WebSocket nanti)
        System.out.println("NOTIFIKASI: " + message);
        // Untuk sementara, tampilkan di console
    }
}