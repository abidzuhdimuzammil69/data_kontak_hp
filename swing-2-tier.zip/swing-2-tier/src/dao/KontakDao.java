package dao;

import java.util.List;
import model.Kontak;

public interface KontakDao {
    void insert(Kontak kontak);
    void update(Kontak kontak);
    void delete(int id);
    List<Kontak> findAll();
    List<Kontak> searchByNama(String keyword);
}