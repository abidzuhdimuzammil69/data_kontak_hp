package dao.mysql;

import config.DatabaseConnection;
import dao.KontakDao;
import model.Kontak;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class KontakDaoMySql implements KontakDao {

    @Override
    public void insert(Kontak kontak) {
        String sql = "INSERT INTO kontaks (nama, telepon, email) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, kontak.getNama());
            stmt.setString(2, kontak.getTelepon());
            stmt.setString(3, kontak.getEmail());
            stmt.executeUpdate();
            
            // Ambil ID yang di-generate
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    kontak.setId(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to insert kontak: " + e.getMessage());
        }
    }

    @Override
    public void update(Kontak kontak) {
        String sql = "UPDATE kontaks SET nama = ?, telepon = ?, email = ? WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, kontak.getNama());
            stmt.setString(2, kontak.getTelepon());
            stmt.setString(3, kontak.getEmail());
            stmt.setInt(4, kontak.getId());
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to update kontak: " + e.getMessage());
        }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM kontaks WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to delete kontak: " + e.getMessage());
        }
    }

    @Override
    public List<Kontak> findAll() {
        List<Kontak> kontakList = new ArrayList<>();
        String sql = "SELECT * FROM kontaks ORDER BY nama";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                kontakList.add(extractKontakFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load kontaks: " + e.getMessage());
        }
        return kontakList;
    }

    @Override
    public List<Kontak> searchByNama(String keyword) {
        List<Kontak> kontakList = new ArrayList<>();
        String sql = "SELECT * FROM kontaks WHERE nama LIKE ? ORDER BY nama";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, "%" + keyword + "%");
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    kontakList.add(extractKontakFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to search kontaks: " + e.getMessage());
        }
        return kontakList;
    }
    
    private Kontak extractKontakFromResultSet(ResultSet rs) throws SQLException {
        Kontak kontak = new Kontak();
        kontak.setId(rs.getInt("id"));
        kontak.setNama(rs.getString("nama"));
        kontak.setTelepon(rs.getString("telepon"));
        kontak.setEmail(rs.getString("email"));
        
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            kontak.setCreatedAt(createdAt.toLocalDateTime());
        }
        
        Timestamp updatedAt = rs.getTimestamp("updated_at");
        if (updatedAt != null) {
            kontak.setUpdatedAt(updatedAt.toLocalDateTime());
        }
        
        return kontak;
    }
}