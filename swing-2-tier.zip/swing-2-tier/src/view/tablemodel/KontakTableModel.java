package view.tablemodel;

import model.Kontak;
import javax.swing.table.AbstractTableModel;
import java.util.List;
import java.util.ArrayList;

public class KontakTableModel extends AbstractTableModel {
    private List<Kontak> kontakList = new ArrayList<>();
    private final String[] columnNames = {"ID", "Nama", "Telepon", "Email", "Dibuat", "Diperbarui"};

    public void setKontakList(List<Kontak> kontakList) {
        this.kontakList = kontakList;
        fireTableDataChanged();
    }

    public Kontak getKontakAt(int rowIndex) {
        if (rowIndex >= 0 && rowIndex < kontakList.size()) {
            return kontakList.get(rowIndex);
        }
        return null;
    }

    @Override
    public int getRowCount() {
        return kontakList.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Kontak kontak = kontakList.get(rowIndex);
        switch (columnIndex) {
            case 0: return kontak.getId();
            case 1: return kontak.getNama();
            case 2: return kontak.getTelepon();
            case 3: return kontak.getEmail();
            case 4: return kontak.getCreatedAt();
            case 5: return kontak.getUpdatedAt();
            default: return null;
        }
    }
    
    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0: return Integer.class;
            default: return String.class;
        }
    }
}