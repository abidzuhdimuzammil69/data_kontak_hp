package view;

import view.tablemodel.KontakTableModel;
import javax.swing.*;
import java.awt.*;
import net.miginfocom.swing.MigLayout;

public class KontakFrame extends JFrame {
    private final JTextField searchField = new JTextField(30);
    private final JButton addButton = new JButton("Tambah Baru");
    private final JButton refreshButton = new JButton("Refresh");
    private final JButton deleteButton = new JButton("Hapus");
    private final JButton exportButton = new JButton("Export PDF");
    private final JLabel totalRecordsLabel = new JLabel("0 Kontak");
    
    private final JTable kontakTable = new JTable();
    private final KontakTableModel kontakTableModel = new KontakTableModel();
    private final JProgressBar progressBar = new JProgressBar();

    public KontakFrame() {
        initializeUI();
    }

    private void initializeUI() {
        setTitle("Manajemen Kontak - 2 Tier Architecture");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new MigLayout("fill, insets 20", "[grow]", "[]10[]10[grow]10[]10[]"));
        
        kontakTable.setModel(kontakTableModel);
        kontakTable.setAutoCreateRowSorter(true);
        progressBar.setStringPainted(true);

        // Header
        JLabel titleLabel = new JLabel("Manajemen Kontak");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(titleLabel, "wrap, span 2");
        
        // Search Panel
        JPanel searchPanel = new JPanel(new MigLayout(""));
        searchPanel.add(new JLabel("Cari Nama:"));
        searchPanel.add(searchField, "growx");
        add(searchPanel, "growx, w 70%");
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new MigLayout("right"));
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(exportButton);
        buttonPanel.add(addButton);
        add(buttonPanel, "wrap, right, w 30%");
        
        // Table
        add(new JScrollPane(kontakTable), "grow, wrap, span 2");
        
        // Status Bar
        add(progressBar, "growx, h 20!, wrap, span 2");
        add(totalRecordsLabel, "right, span 2");

        pack();
        setMinimumSize(new Dimension(1000, 600));
        setLocationRelativeTo(null);
    }

    // Getter methods
    public JTextField getSearchField() { return searchField; }
    public JButton getAddButton() { return addButton; }
    public JButton getRefreshButton() { return refreshButton; }
    public JButton getDeleteButton() { return deleteButton; }
    public JButton getExportButton() { return exportButton; }
    public JTable getKontakTable() { return kontakTable; }
    public KontakTableModel getKontakTableModel() { return kontakTableModel; }
    public JProgressBar getProgressBar() { return progressBar; }
    public JLabel getTotalRecordsLabel() { return totalRecordsLabel; }
}